export const suggestedCities = [
  {
    city: "تهران",
    province: "تهران",
    cityId: "city_3f0413c902fe727d690cea0b08fa430121265925",
  },
  {
    city: "اصفهان",
    province: "اصفهان",
    cityId: "city_14600c187a7e7c4473442ff2dd5a2bbbe6662513",
  },
  {
    city: "مشهد",
    province: "خراسان رضوی",
    cityId: "city_464f096af53bbd4c4960a11b02ffb09d9abee838",
  },
  {
    city: "رشت",
    province: "گیلان",
    cityId: "city_c1fdbf106192f490c0b89526c67d9593059544d2",
  },
  {
    city: "تبریز",
    province: "آذربایجان شرقی",
    cityId: "city_2a15f6b3fc30a239ea5e1232c3ae704a1413e01f",
  },
  {
    city: "شهرکرد",
    province: "چهارمحال و بختیاری",
    cityId: "city_0bb81d7915f2b027db4d1d49496c3d107fbf313d",
  },
];
